﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Text.RegularExpressions;

namespace CS422
{
  public class WebServer
  {

    public WebServer()
    {

    }

    public static bool Start(int port, string responseTemplate)
    {
      TcpListener listener = new TcpListener(IPAddress.Any, port);
      TcpClient client;
      listener.Start();
      byte[] buf = new byte[4096];

      try
      {
        client = listener.AcceptTcpClient();
      }
      catch
      {
        return false;
      }

      if (ReadRequest(client, ref buf))
      {
        WriteResponse(client, buf, responseTemplate);
        client.GetStream().Close();
        client.Close();
      }
      else
      {
        client.GetStream().Close();
        client.Close();
        return false;
      }
      return true;
    }

    private static bool ReadRequest(TcpClient client, ref byte[] buf)
    {
      NetworkStream ns = client.GetStream();
      int numBytes = 0;
      int totalBytes = 0;

      numBytes = ns.Read(buf, 0, 4096);

      // While still reading OR reached the double line break (body)
      while (numBytes != 0)
      {
        totalBytes += numBytes;
        if (!CheckRequest(buf, totalBytes, false))
        {
          return false;
        }
        if (!ns.DataAvailable)
        {
          break;
        }
        numBytes = ns.Read(buf, totalBytes, 4096 - totalBytes);
      }

      return CheckRequest(buf, totalBytes, true);
    }

    private static bool CheckRequest(byte[] request, int bytes, bool finished)
    {
      Regex version = new Regex(@"HTTP/(\d+\.\d+)");

      if (Encoding.ASCII.GetString(request, 0, bytes < 4 ? bytes : 4) != "GET " || (finished && bytes < 4))
      {
        return false;
      }
      // If finished and no version match
      if (finished && !version.IsMatch(Encoding.ASCII.GetString(request)))
      {
        return false;
      }
      // Otherwise, if version match, check for valid version
      else if (version.IsMatch(Encoding.ASCII.GetString(request, 0, bytes)))
      {
        // parse out version and check for validity
        Regex deci = new Regex(@"\d+\.\d+");
        if (deci.Match(version.Match(Encoding.ASCII.GetString(request, 0, bytes)).ToString()).ToString() != "1.1")
        {
          return false;
        }
      }
      return true;
    }

    private static void WriteResponse(TcpClient client, byte[] buf, string template)
    {
      string response = String.Format(template, "11239845", DateTime.Now, Encoding.ASCII.GetString(buf).Substring(4).Split(' ')[0]);

      client.GetStream().Write(Encoding.ASCII.GetBytes(response), 0, response.Length);
    }
  }
}
